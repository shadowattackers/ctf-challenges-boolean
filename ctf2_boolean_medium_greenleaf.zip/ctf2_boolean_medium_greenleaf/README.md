# CTF 2: Boolean Based SQL Injection (MEDIUM)

Challenge name: GreenLeaf Library
Category: Web
Difficulty: Medium
Flag format: CGS{...}
Flag length: 20 characters

## Run locally

```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Run with Docker

```
docker compose up -d --build
```
Open http://SERVER-IP:8002

To change the flag, edit CTF_FLAG_PART1 / CTF_FLAG_PART2 / CTF_FLAG_PART3
in docker-compose.yml (or set them as environment variables before
running app.py directly).

## Challenge description (give to players)

GreenLeaf Community Library ki website par sirf ek public catalog hai.
Lekin library ke purane system mein ek internal reference tool bhi
chhupa hua hai, jo website ke menu mein kahin link nahi hai. Agar aap
usse dhoondh len, to shayad wahan se kuch aur bhi mil jaye. Flag teen
hisson mein bata hua hai.

Flag format: CGS{...}

## Hints (give to players)

- Hint 1: Website ke menu mein sab kuch nahi dikhta. Page ka source code
  aur robots.txt bhi check karein.
- Hint 2: Ye tool kuch keywords aur spaces rok deta hai, lekin bilkul
  chup chaap, koi "blocked" message nahi dikhata. Rukawat aur galat
  jawab ek jaise dikhte hain.
- Hint 3: substr aur length jaisi common functions yahan kaam nahi
  karengi. Kisi aur tareeqe se character check karna hoga.
- Hint 4: Flag ek jagah nahi, teen alag jagah rakha gaya hai.

See SOLUTION.md for the full walkthrough and the flag. Do not share that
file with players.
