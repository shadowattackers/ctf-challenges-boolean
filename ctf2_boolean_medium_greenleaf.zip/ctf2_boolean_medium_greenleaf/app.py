import os
import re
import sqlite3
from flask import Flask, request, render_template, abort
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)
limiter = Limiter(get_remote_address, app=app, storage_uri="memory://")
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "greenleaf.db")
FLAG_PART1 = os.environ.get("CTF_FLAG_PART1", "m3d_")
FLAG_PART2 = os.environ.get("CTF_FLAG_PART2", "l1ke_")
FLAG_PART3 = os.environ.get("CTF_FLAG_PART3", "h1dd3n")

# Stricter filter: blocks whitespace plus several common blind-SQLi helper
# functions/keywords. substr/length/count are deliberately blocked so the
# obvious length+substr technique from the easy challenge does not work here.
BLOCKED_KEYWORDS = [
    "union", "sleep", "benchmark", "substr", "substring", "length",
    "count", "hex", "char(", "load_extension", "randomblob",
    "group_concat", "--", "/*", "#",
]


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    for t in ("books", "members", "secure_meta", "archive_meta", "vault_notes"):
        cur.execute("DROP TABLE IF EXISTS " + t)
    cur.execute("CREATE TABLE books (id INTEGER PRIMARY KEY, title TEXT, author TEXT, genre TEXT, summary TEXT, available INTEGER)")
    cur.execute("CREATE TABLE members (id INTEGER PRIMARY KEY, name TEXT, role TEXT)")
    cur.execute("CREATE TABLE secure_meta (id INTEGER PRIMARY KEY, tag TEXT, payload TEXT)")
    cur.execute("CREATE TABLE archive_meta (id INTEGER PRIMARY KEY, tag TEXT, payload TEXT)")
    cur.execute("CREATE TABLE vault_notes (id INTEGER PRIMARY KEY, tag TEXT, payload TEXT)")
    books = [
        ("The Silent Orchard", "R. Malik", "Fiction", "A family saga set across three generations.", 1),
        ("Deep Currents", "S. Noor", "Non-fiction", "An account of ocean exploration.", 1),
        ("Paper Lanterns", "A. Hayat", "Poetry", "A collection on memory and distance.", 1),
        ("The Clockmaker's Son", "F. Baig", "Fiction", "A mystery set in old Lahore.", 1),
        ("Desert Winds", "H. Qureshi", "Travel", "Notes from a journey across Balochistan.", 1),
        ("Code and Clay", "N. Siddiqui", "Technology", "Essays on craft and software.", 1),
        ("Quiet Mountains", "Z. Abbasi", "Travel", "A trek through the northern valleys.", 1),
        ("Restricted Archive Index", "Library Staff", "Internal", "Staff-only archive index. Not for public lending.", 0),
    ]
    cur.executemany("INSERT INTO books (title, author, genre, summary, available) VALUES (?, ?, ?, ?, ?)", books)
    cur.executemany("INSERT INTO members (name, role) VALUES (?, ?)", [
        ("Imran", "Librarian"), ("Sana", "Assistant"), ("Library Staff", "Admin")])
    cur.executemany("INSERT INTO secure_meta (tag, payload) VALUES (?, ?)", [
        ("note", "shelving plan v2"), ("part_one", FLAG_PART1)])
    cur.executemany("INSERT INTO archive_meta (tag, payload) VALUES (?, ?)", [
        ("note", "old catalog backup"), ("part_two", FLAG_PART2)])
    cur.executemany("INSERT INTO vault_notes (tag, payload) VALUES (?, ?)", [
        ("note", "misc"), ("part_three", FLAG_PART3)])
    conn.commit()
    conn.close()


def db():
    return sqlite3.connect(DB_PATH)


def is_blocked(value):
    if re.search(r"\s", value):
        return True
    low = value.lower()
    for word in BLOCKED_KEYWORDS:
        if word in low:
            return True
    return False


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/contact", methods=["GET", "POST"])
def contact():
    sent = request.method == "POST"
    return render_template("contact.html", sent=sent)


@app.route("/catalog")
def catalog():
    genre = request.args.get("genre", "")
    conn = db()
    if genre:
        rows = conn.execute("SELECT id, title, author, genre FROM books WHERE available = 1 AND genre = ?", (genre,)).fetchall()
    else:
        rows = conn.execute("SELECT id, title, author, genre FROM books WHERE available = 1").fetchall()
    genres = [r[0] for r in conn.execute("SELECT DISTINCT genre FROM books WHERE available = 1").fetchall()]
    conn.close()
    return render_template("catalog.html", rows=rows, genres=genres, selected=genre)


@app.route("/book")
def book():
    bid = request.args.get("id", "")
    if bid == "":
        abort(404)
    try:
        conn = db()
        row = conn.execute(
            "SELECT id, title, author, genre, summary FROM books WHERE id = ? AND available = 1",
            (bid,),
        ).fetchone()
        conn.close()
    except Exception:
        row = None
    if row is None:
        return render_template("book.html", book=None), 404
    return render_template("book.html", book=row)


@app.route("/catalog/lookup")
@limiter.limit("20 per minute")
def lookup():
    # Legacy lookup route kept for an internal reporting tool.
    # Not linked anywhere in the site navigation.
    ref = request.args.get("ref", "")
    found = False
    row = None
    if ref != "" and not is_blocked(ref):
        # VULNERABLE: input is concatenated directly into the query.
        query = "SELECT id, title, author, genre, summary FROM books WHERE id = " + ref
        try:
            conn = db()
            row = conn.execute(query).fetchone()
            conn.close()
            found = row is not None
        except Exception:
            found = False
    return render_template("lookup.html", found=found, row=row)


@app.route("/robots.txt")
def robots():
    return (
        "User-agent: *\n"
        "Disallow: /catalog/lookup\n",
        200,
        {"Content-Type": "text/plain"},
    )


@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
