# CTF 1: Boolean Based SQL Injection (EASY)

Challenge name: CampusCare HelpDesk
Category: Web
Difficulty: Easy
Flag format: CGS{...}
Flag length: 22 characters

## Run locally

```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Run with Docker

```
docker compose up -d --build
```
Open http://SERVER-IP:8001

To change the flag, edit CTF_FLAG_PART1 / CTF_FLAG_PART2 in docker-compose.yml
(or set them as environment variables before running app.py directly).

## Challenge description (give to players)

CampusCare ki IT HelpDesk website par public support tickets dikhaye jate
hain. Lekin ek restricted ticket aur kuch internal notes sab ki nazar se
chhupe hue hain. Kya aap wo chhupa hua key dhoondh sakte hain? Key do
hisson mein hai. Dono hisse jod kar poora flag banta hai.

Flag format: CGS{...}

## Hints (give to players)

- Hint 1: Sirf wahi cheez dekho jo aapke control mein ho. Ek parameter ko
  dhyan se dekho.
- Hint 2: Website kuch characters ko rok deti hai. Rukawat ka matlab ye
  nahi ke raasta band hai.
- Hint 3: Page seedha data nahi dikhata, sirf haan ya nahin jaisa jawab
  deta hai.

See SOLUTION.md for the full walkthrough and the flag. Do not share that
file with players.
