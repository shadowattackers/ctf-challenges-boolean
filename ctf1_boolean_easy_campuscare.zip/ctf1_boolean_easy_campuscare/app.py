import os
import re
import sqlite3
from flask import Flask, request, render_template, abort
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)
limiter = Limiter(get_remote_address, app=app, storage_uri="memory://")
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "helpdesk.db")
FLAG_PART1 = os.environ.get("CTF_FLAG_PART1", "b00l_")
FLAG_PART2 = os.environ.get("CTF_FLAG_PART2", "tick3t_p4rts")

# Simple filter: blocks whitespace and a few common keywords.
BLOCKED_KEYWORDS = ["union", "sleep", "benchmark", "load_extension", "randomblob", "--", "/*", "#"]


def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    for t in ("tickets", "staff", "vault_a", "vault_b"):
        cur.execute("DROP TABLE IF EXISTS " + t)
    cur.execute("CREATE TABLE tickets (id INTEGER PRIMARY KEY, subject TEXT, status TEXT, department TEXT, details TEXT, is_public INTEGER)")
    cur.execute("CREATE TABLE staff (id INTEGER PRIMARY KEY, name TEXT, role TEXT)")
    cur.execute("CREATE TABLE vault_a (id INTEGER PRIMARY KEY, label TEXT, content TEXT)")
    cur.execute("CREATE TABLE vault_b (id INTEGER PRIMARY KEY, label TEXT, content TEXT)")
    tickets = [
        ("Cannot reset my password", "Resolved", "Accounts", "User was guided through the reset process.", 1),
        ("Printer on floor 2 offline", "Open", "IT Support", "Technician has been assigned.", 1),
        ("VPN keeps disconnecting", "In Progress", "Network", "Investigating unstable connection on the gateway.", 1),
        ("Request for new monitor", "Resolved", "Procurement", "Monitor delivered to desk 14.", 1),
        ("Email not syncing on phone", "Open", "IT Support", "Waiting for user to share device model.", 1),
        ("Software license renewal", "In Progress", "Procurement", "Renewal approved, payment pending.", 1),
        ("Wi-Fi slow in meeting room", "Resolved", "Network", "Access point was replaced.", 1),
        ("Server audit notes", "Closed", "Security", "Restricted ticket. Staff only.", 0),
    ]
    cur.executemany("INSERT INTO tickets (subject, status, department, details, is_public) VALUES (?, ?, ?, ?, ?)", tickets)
    cur.executemany("INSERT INTO staff (name, role) VALUES (?, ?)", [
        ("Ayesha", "Agent"), ("Bilal", "Agent"), ("Hamza", "Team Lead")])
    cur.executemany("INSERT INTO vault_a (label, content) VALUES (?, ?)", [
        ("note", "nothing here"), ("key_part_1", FLAG_PART1)])
    cur.executemany("INSERT INTO vault_b (label, content) VALUES (?, ?)", [
        ("note", "archive"), ("key_part_2", FLAG_PART2)])
    conn.commit()
    conn.close()


def db():
    return sqlite3.connect(DB_PATH)


def is_blocked(value):
    low = value.lower()
    if re.search(r"\s", value):
        return True
    for word in BLOCKED_KEYWORDS:
        if word in low:
            return True
    return False


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/faq")
def faq():
    return render_template("faq.html")


@app.route("/submit", methods=["GET", "POST"])
def submit():
    sent = request.method == "POST"
    return render_template("submit.html", sent=sent)


@app.route("/tickets")
def tickets():
    dept = request.args.get("department", "")
    conn = db()
    if dept:
        rows = conn.execute("SELECT id, subject, status, department FROM tickets WHERE is_public = 1 AND department = ?", (dept,)).fetchall()
    else:
        rows = conn.execute("SELECT id, subject, status, department FROM tickets WHERE is_public = 1").fetchall()
    depts = [r[0] for r in conn.execute("SELECT DISTINCT department FROM tickets WHERE is_public = 1").fetchall()]
    conn.close()
    return render_template("tickets.html", rows=rows, depts=depts, selected=dept)


@app.route("/ticket")
@limiter.limit("20 per minute")
def ticket():
    tid = request.args.get("id", "")
    if tid == "":
        abort(404)
    if is_blocked(tid):
        return render_template("ticket.html", ticket=None, blocked=True), 400
    # VULNERABLE: input is concatenated directly into the query.
    query = "SELECT id, subject, status, department, details FROM tickets WHERE id = " + tid + " AND is_public = 1"
    try:
        conn = db()
        row = conn.execute(query).fetchone()
        conn.close()
    except Exception:
        row = None
    if row is None:
        return render_template("ticket.html", ticket=None, blocked=False), 404
    return render_template("ticket.html", ticket=row, blocked=False)


@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
